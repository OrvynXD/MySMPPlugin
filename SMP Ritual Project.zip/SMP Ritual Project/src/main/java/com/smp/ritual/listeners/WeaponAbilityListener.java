package com.smp.ritual.listeners;

import com.smp.ritual.SMPRitualPlugin;
import com.smp.ritual.models.CustomWeapon;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class WeaponAbilityListener implements Listener {

    private final SMPRitualPlugin plugin;
    private final Map<UUID, ComboTracker> redlineCombos = new HashMap<>();
    private final Map<UUID, Long> gravehookCooldowns = new HashMap<>();

    private static class ComboTracker {
        int combo = 1;
        long lastHitTime = System.currentTimeMillis();
    }

    public WeaponAbilityListener(SMPRitualPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onWeaponAttack(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        if (!(event.getEntity() instanceof LivingEntity victim)) return;

        ItemStack hand = player.getInventory().getItemInMainHand();
        CustomWeapon weapon = plugin.getWeaponManager().getCustomWeapon(hand);
        if (weapon == null) return;

        String id = weapon.getId();
        World world = player.getWorld();
        Location victimLoc = victim.getLocation();
        MiniMessage mm = plugin.getMiniMessage();

        // 1. Ironwake: Ground Slam on fall/jump
        if (id.startsWith("ironwake")) {
            if (player.getFallDistance() > 0.0f || player.isSneaking()) {
                double radius = id.contains("awakened") ? 5.5 : 4.0;
                double shockDamage = id.contains("awakened") ? 7.0 : 4.5;

                world.playSound(victimLoc, Sound.ENTITY_ZOMBIE_BREAK_WOODEN_DOOR, 1.0f, 0.7f);
                world.playSound(victimLoc, Sound.ENTITY_GENERIC_EXPLODE, 0.7f, 1.2f);
                world.spawnParticle(Particle.BLOCK, victimLoc, 60, 1.5, 0.2, 1.5, Material.COBBLESTONE.createBlockData());
                world.spawnParticle(Particle.EXPLOSION, victimLoc, 2);

                for (Entity nearby : world.getNearbyEntities(victimLoc, radius, radius, radius)) {
                    if (nearby instanceof LivingEntity target && !nearby.equals(player) && !nearby.equals(victim)) {
                        target.damage(shockDamage, player);
                        Vector knockback = target.getLocation().toVector().subtract(victimLoc.toVector()).normalize().multiply(0.9).setY(0.4);
                        target.setVelocity(knockback);
                    }
                }
            }
        }

        // 2. Redline: Consecutive combo stacking
        else if (id.startsWith("redline")) {
            long now = System.currentTimeMillis();
            ComboTracker tracker = redlineCombos.computeIfAbsent(player.getUniqueId(), k -> new ComboTracker());
            int maxCombo = id.contains("awakened") ? 5 : 3;

            if (now - tracker.lastHitTime <= 3000) {
                tracker.combo = Math.min(maxCombo, tracker.combo + 1);
            } else {
                tracker.combo = 1;
            }
            tracker.lastHitTime = now;

            double multiplier = 1.0 + (tracker.combo * 0.15);
            event.setDamage(event.getDamage() * multiplier);

            player.sendActionBar(mm.deserialize(
                    "<red><bold>⚡ REDLINE COMBO x" + tracker.combo + "!</bold> <gray>(+" + (int)((multiplier - 1.0) * 100) + "% DMG)</gray></red>"
            ));
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 50, tracker.combo - 1, true, false, false));
            world.spawnParticle(Particle.SWEEP_ATTACK, victimLoc.add(0, 1, 0), tracker.combo);
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1.0f, 1.0f + (tracker.combo * 0.2f));
        }

        // 3. Stormbrand: Lightning strike chance
        else if (id.equals("stormbrand")) {
            if (Math.random() < 0.35) {
                world.strikeLightningEffect(victimLoc);
                victim.damage(5.0, player);
                world.playSound(victimLoc, Sound.ITEM_TRIDENT_THUNDER, 1.0f, 1.2f);
                world.spawnParticle(Particle.ELECTRIC_SPARK, victimLoc.add(0, 1, 0), 30, 0.4, 0.8, 0.4, 0.1);
            }
        }

        // 4. Ashen Pike: Hellfire burn
        else if (id.equals("ashen_pike")) {
            victim.setFireTicks(120); // 6 seconds of fire
            world.spawnParticle(Particle.FLAME, victimLoc.add(0, 1, 0), 25, 0.4, 0.6, 0.4, 0.05);
            world.playSound(victimLoc, Sound.ITEM_FIRECHARGE_USE, 0.8f, 1.0f);
        }

        // 5. Sunstroke: Burst damage on critical
        else if (id.equals("sunstroke")) {
            if (player.getFallDistance() > 0.0f) {
                event.setDamage(event.getDamage() * 2.0); // 200% burst
                victim.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 0));
                world.playSound(victimLoc, Sound.ENTITY_FIREWORK_ROCKET_BLAST, 1.2f, 0.9f);
                world.spawnParticle(Particle.FLASH, victimLoc.add(0, 1, 0), 3);
                world.spawnParticle(Particle.GLOW, victimLoc.add(0, 1, 0), 40, 0.5, 0.5, 0.5, 0.2);
            }
        }

        // 6. Hollowedge: High risk / reward
        else if (id.equals("hollowedge")) {
            if (player.getHealth() <= (player.getMaxHealth() / 2.0)) {
                event.setDamage(event.getDamage() * 1.5); // +50% bonus
                world.spawnParticle(Particle.SOUL, victimLoc.add(0, 1, 0), 20, 0.3, 0.5, 0.3, 0.05);
                player.playSound(player.getLocation(), Sound.ENTITY_VEX_HURT, 0.7f, 0.8f);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onHollowedgeDefend(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        ItemStack hand = player.getInventory().getItemInMainHand();
        CustomWeapon weapon = plugin.getWeaponManager().getCustomWeapon(hand);
        if (weapon != null && "hollowedge".equals(weapon.getId())) {
            event.setDamage(event.getDamage() * 1.20); // takes 20% extra damage
        }
    }

    @EventHandler
    public void onGravehookCast(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack hand = player.getInventory().getItemInMainHand();
        CustomWeapon weapon = plugin.getWeaponManager().getCustomWeapon(hand);
        if (weapon == null || !"gravehook".equals(weapon.getId())) return;

        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        long now = System.currentTimeMillis();
        long last = gravehookCooldowns.getOrDefault(player.getUniqueId(), 0L);
        if (now - last < 8000) {
            long remaining = 8 - ((now - last) / 1000);
            player.sendMessage(plugin.getMiniMessage().deserialize("<red>Gravehook is on cooldown: <white>" + remaining + "s</white></red>"));
            return;
        }

        gravehookCooldowns.put(player.getUniqueId(), now);
        World world = player.getWorld();
        Location eye = player.getEyeLocation();
        Vector dir = eye.getDirection().normalize();

        RayTraceResult result = world.rayTraceEntities(eye, dir, 16.0, 1.2, e -> !e.equals(player) && e instanceof LivingEntity);

        // Particle beam
        for (double d = 0; d < 16; d += 0.5) {
            Location pLoc = eye.clone().add(dir.clone().multiply(d));
            world.spawnParticle(Particle.CRIT, pLoc, 1, 0, 0, 0, 0);
        }
        player.playSound(player.getLocation(), Sound.BLOCK_CHAIN_PLACE, 1.0f, 1.4f);

        if (result != null && result.getHitEntity() instanceof LivingEntity target) {
            Vector pull = player.getLocation().toVector().subtract(target.getLocation().toVector()).normalize().multiply(1.6).setY(0.4);
            target.setVelocity(pull);
            target.damage(4.0, player);

            player.playSound(player.getLocation(), Sound.BLOCK_CHAIN_BREAK, 1.0f, 0.9f);
            player.sendMessage(plugin.getMiniMessage().deserialize("<green><bold>Hooked " + target.getName() + "!</bold></green>"));
        } else {
            player.sendMessage(plugin.getMiniMessage().deserialize("<gray>Gravehook missed!</gray>"));
        }
    }

    @EventHandler
    public void onShootRiftBow(EntityShootBowEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        ItemStack bow = event.getBow();
        CustomWeapon weapon = plugin.getWeaponManager().getCustomWeapon(bow);
        if (weapon == null || !"rift_bow".equals(weapon.getId())) return;

        if (player.isSneaking() && event.getProjectile() instanceof Arrow arrow) {
            NamespacedKey key = new NamespacedKey(plugin, "rift_arrow");
            arrow.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
            player.sendMessage(plugin.getMiniMessage().deserialize("<light_purple>✦ Rift shot fired! Ready for teleport!</light_purple>"));
        }
    }

    @EventHandler
    public void onRiftArrowHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof Arrow arrow)) return;
        NamespacedKey key = new NamespacedKey(plugin, "rift_arrow");
        if (!arrow.getPersistentDataContainer().has(key, PersistentDataType.BYTE)) return;

        if (arrow.getShooter() instanceof Player player && player.isOnline()) {
            Location hitLoc = event.getHitBlock() != null ? event.getHitBlock().getLocation().add(0.5, 1, 0.5) :
                    event.getHitEntity() != null ? event.getHitEntity().getLocation() : arrow.getLocation();

            World world = player.getWorld();
            world.spawnParticle(Particle.PORTAL, player.getLocation(), 40, 0.5, 1, 0.5, 0.2);
            player.teleport(hitLoc);
            world.spawnParticle(Particle.PORTAL, hitLoc, 50, 0.5, 1, 0.5, 0.2);
            world.playSound(hitLoc, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.1f);
            player.sendMessage(plugin.getMiniMessage().deserialize("<light_purple><bold>✦ Rift Shifted to impact! ✦</bold></light_purple>"));
        }
    }
}
