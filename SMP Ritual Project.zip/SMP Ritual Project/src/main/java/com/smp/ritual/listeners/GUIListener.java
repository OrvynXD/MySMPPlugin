package com.smp.ritual.listeners;

import com.smp.ritual.SMPRitualPlugin;
import com.smp.ritual.managers.GUIManager;
import com.smp.ritual.models.RitualRecipe;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

public class GUIListener implements Listener {

    private final SMPRitualPlugin plugin;

    public GUIListener(SMPRitualPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        if (event.getView().title().equals(plugin.getMiniMessage().deserialize(GUIManager.TRACKER_TITLE))) {
            event.setCancelled(true);
            return;
        }

        // Check if viewing our custom ritual crafting menu
        if (event.getView().title().equals(plugin.getMiniMessage().deserialize(GUIManager.GUI_TITLE))) {
            event.setCancelled(true);

            ItemStack clicked = event.getCurrentItem();
            if (clicked == null || !clicked.hasItemMeta()) return;

            NamespacedKey key = new NamespacedKey(plugin, "recipe_id");
            PersistentDataContainer pdc = clicked.getItemMeta().getPersistentDataContainer();
            if (!pdc.has(key, PersistentDataType.STRING)) return;

            String recipeId = pdc.get(key, PersistentDataType.STRING);
            RitualRecipe recipe = plugin.getRitualManager().getRecipe(recipeId);
            if (recipe == null) return;

            // Dimension check (e.g. Overworld recipes can only be started in Overworld, Nether in Nether)
            String worldEnv = player.getWorld().getEnvironment().name();
            if (!worldEnv.equalsIgnoreCase(recipe.getDimension())) {
                player.sendMessage(plugin.getMiniMessage().deserialize(
                        "<red>This ritual can only be conducted in the " + recipe.getDimension() + "!</red>"
                ));
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
                return;
            }

            // Check ingredients
            if (!plugin.getGuiManager().hasIngredients(player, recipe)) {
                player.sendMessage(plugin.getMiniMessage().deserialize(
                        "<red>You do not have all required ingredients to begin this ritual!</red>"
                ));
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
                return;
            }

            // Consume ingredients and initiate ritual
            if (plugin.getGuiManager().consumeIngredients(player, recipe)) {
                boolean started = plugin.getRitualManager().startRitual(player, recipe, player.getLocation().getBlock().getLocation());
                if (started) {
                    player.closeInventory();
                    player.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 0.8f);
                    player.sendMessage(plugin.getMiniMessage().deserialize(
                            "<green>Ritual ingredients consumed! The ritual has begun at your feet!</green>"
                    ));
                }
            }
        }
    }
}
