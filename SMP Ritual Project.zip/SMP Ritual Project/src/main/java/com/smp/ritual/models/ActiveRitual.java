package com.smp.ritual.models;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Location;

import java.util.UUID;

public class ActiveRitual {

    private final RitualRecipe recipe;
    private final Location location;
    private final UUID starterUUID;
    private final String starterName;
    private int elapsedSeconds;
    private final int totalSeconds;
    private BossBar bossBar;
    private boolean completed;
    private boolean claimed;
    private UUID claimEntityUUID;

    public ActiveRitual(RitualRecipe recipe, Location location, UUID starterUUID, String starterName) {
        this.recipe = recipe;
        this.location = location;
        this.starterUUID = starterUUID;
        this.starterName = starterName;
        this.elapsedSeconds = 0;
        this.totalSeconds = recipe.getDurationSeconds();
        this.completed = false;
        this.claimed = false;
    }

    public boolean isYRevealed() {
        return elapsedSeconds >= recipe.getYRevealSeconds();
    }

    public boolean isXRevealed() {
        return elapsedSeconds >= recipe.getXRevealSeconds();
    }

    public boolean isZRevealed() {
        return elapsedSeconds >= recipe.getZRevealSeconds();
    }

    public String getFormattedCoordinates() {
        String xStr = isXRevealed() ? String.valueOf(location.getBlockX()) : "<obfuscated>???</obfuscated>";
        String yStr = isYRevealed() ? String.valueOf(location.getBlockY()) : "<obfuscated>???</obfuscated>";
        String zStr = isZRevealed() ? String.valueOf(location.getBlockZ()) : "<obfuscated>???</obfuscated>";

        return "<yellow>X:</yellow> <white>" + xStr + "</white> " +
               "<yellow>Y:</yellow> <white>" + yStr + "</white> " +
               "<yellow>Z:</yellow> <white>" + zStr + "</white>";
    }

    public String getRemainingTimeFormatted() {
        int remaining = Math.max(0, totalSeconds - elapsedSeconds);
        int minutes = remaining / 60;
        int seconds = remaining % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    public void tick() {
        if (!completed) {
            elapsedSeconds++;
            if (elapsedSeconds >= totalSeconds) {
                completed = true;
            }
        }
    }

    public void fastForward(int seconds) {
        elapsedSeconds = Math.min(totalSeconds, elapsedSeconds + seconds);
        if (elapsedSeconds >= totalSeconds) {
            completed = true;
        }
    }

    public RitualRecipe getRecipe() { return recipe; }
    public Location getLocation() { return location; }
    public UUID getStarterUUID() { return starterUUID; }
    public String getStarterName() { return starterName; }
    public int getElapsedSeconds() { return elapsedSeconds; }
    public int getTotalSeconds() { return totalSeconds; }
    public BossBar getBossBar() { return bossBar; }
    public void setBossBar(BossBar bossBar) { this.bossBar = bossBar; }
    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }
    public boolean isClaimed() { return claimed; }
    public void setClaimed(boolean claimed) { this.claimed = claimed; }
    public UUID getClaimEntityUUID() { return claimEntityUUID; }
    public void setClaimEntityUUID(UUID claimEntityUUID) { this.claimEntityUUID = claimEntityUUID; }
}
