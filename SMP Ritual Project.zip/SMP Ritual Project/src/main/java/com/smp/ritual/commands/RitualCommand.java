package com.smp.ritual.commands;

import com.smp.ritual.SMPRitualPlugin;
import com.smp.ritual.models.ActiveRitual;
import com.smp.ritual.models.CustomWeapon;
import com.smp.ritual.models.RitualRecipe;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RitualCommand implements CommandExecutor, TabCompleter {

    private final SMPRitualPlugin plugin;

    public RitualCommand(SMPRitualPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        String sub = args[0].toLowerCase();
        switch (sub) {
            case "start" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Only players can start a ritual at their location.");
                    return true;
                }
                if (args.length < 2) {
                    player.sendMessage(plugin.getMiniMessage().deserialize("<red>Usage: /ritual start <recipe_id></red>"));
                    return true;
                }
                String recipeId = args[1].toLowerCase();
                RitualRecipe recipe = plugin.getRitualManager().getRecipe(recipeId);
                if (recipe == null) {
                    player.sendMessage(plugin.getMiniMessage().deserialize("<red>Unknown recipe ID: " + recipeId + "</red>"));
                    return true;
                }
                plugin.getRitualManager().startRitual(player, recipe, player.getLocation().getBlock().getLocation());
            }
            case "cancel", "stop" -> {
                if (plugin.getRitualManager().getActiveRitual() == null) {
                    sender.sendMessage(plugin.getMiniMessage().deserialize("<red>No active ritual to cancel.</red>"));
                    return true;
                }
                plugin.getRitualManager().cancelRitual();
                sender.sendMessage(plugin.getMiniMessage().deserialize("<yellow>Active ritual has been cancelled.</yellow>"));
            }
            case "fastforward", "ff" -> {
                ActiveRitual active = plugin.getRitualManager().getActiveRitual();
                if (active == null) {
                    sender.sendMessage(plugin.getMiniMessage().deserialize("<red>No active ritual is running.</red>"));
                    return true;
                }
                int seconds = 60;
                if (args.length >= 2) {
                    try {
                        seconds = Integer.parseInt(args[1]);
                    } catch (NumberFormatException ignored) {}
                }
                active.fastForward(seconds);
                sender.sendMessage(plugin.getMiniMessage().deserialize(
                        "<green>Fast-forwarded active ritual by <white>" + seconds + "s</white>! Remaining: <white>" + active.getRemainingTimeFormatted() + "</white></green>"
                ));
            }
            case "claim" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Only players can claim rituals.");
                    return true;
                }
                ActiveRitual active = plugin.getRitualManager().getActiveRitual();
                if (active == null || !active.isCompleted()) {
                    player.sendMessage(plugin.getMiniMessage().deserialize("<red>There is no completed ritual ready to claim.</red>"));
                    return true;
                }
                plugin.getRitualManager().claimReward(player, active);
            }
            case "give" -> {
                if (args.length < 2) {
                    sender.sendMessage(plugin.getMiniMessage().deserialize("<red>Usage: /ritual give <weapon_id> [player]</red>"));
                    return true;
                }
                String weaponId = args[1].toLowerCase();
                CustomWeapon cw = plugin.getWeaponManager().getWeapon(weaponId);
                if (cw == null) {
                    sender.sendMessage(plugin.getMiniMessage().deserialize("<red>Unknown weapon ID: " + weaponId + "</red>"));
                    return true;
                }
                Player target = sender instanceof Player p ? p : null;
                if (args.length >= 3) {
                    target = Bukkit.getPlayer(args[2]);
                }
                if (target == null) {
                    sender.sendMessage(plugin.getMiniMessage().deserialize("<red>Player not found.</red>"));
                    return true;
                }
                ItemStack item = cw.createItemStack(plugin, 0);
                target.getInventory().addItem(item);
                sender.sendMessage(plugin.getMiniMessage().deserialize("<green>Gave " + cw.getDisplayName() + " to " + target.getName() + ".</green>"));
            }
            case "menu" -> {
                if (sender instanceof Player player) {
                    plugin.getGuiManager().openRecipeMenu(player);
                }
            }
            case "track", "tracker" -> {
                if (sender instanceof Player player) {
                    plugin.getGuiManager().openTrackerMenu(player);
                } else {
                    sender.sendMessage("Only players can open the tracker menu.");
                }
            }
            case "reload" -> {
                plugin.reloadConfig();
                plugin.getWeaponManager().loadWeapons();
                plugin.getRitualManager().loadRecipes();
                plugin.getRitualManager().loadClaimedRecipes();
                sender.sendMessage(plugin.getMiniMessage().deserialize("<green>SMP Ritual configurations reloaded!</green>"));
            }
            default -> sendHelp(sender);
        }
        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(plugin.getMiniMessage().deserialize(
                "<gold><bold>SMP Ritual & Weapon Commands:</bold></gold>\n" +
                "<yellow>/ritual start <recipe></yellow> <gray>- Start ritual at your position</gray>\n" +
                "<yellow>/ritual cancel</yellow> <gray>- Cancel currently active ritual</gray>\n" +
                "<yellow>/ritual fastforward <seconds></yellow> <gray>- Skip time ahead in active ritual</gray>\n" +
                "<yellow>/ritual claim</yellow> <gray>- Claim finished ritual</gray>\n" +
                "<yellow>/ritual give <weapon> [player]</yellow> <gray>- Spawn custom weapon</gray>\n" +
                "<yellow>/ritual menu</yellow> <gray>- Open ritual recipe catalog</gray>\n" +
                "<yellow>/ritual track</yellow> <gray>- Open active ritual live tracker</gray>\n" +
                "<yellow>/ritual reload</yellow> <gray>- Reload YAML configs</gray>"
        ));
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        List<String> list = new ArrayList<>();
        if (args.length == 1) {
            List<String> subs = Arrays.asList("start", "cancel", "fastforward", "claim", "give", "menu", "track", "reload");
            for (String s : subs) {
                if (s.startsWith(args[0].toLowerCase())) list.add(s);
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("start")) {
            for (RitualRecipe r : plugin.getRitualManager().getAllRecipes()) {
                if (r.getId().toLowerCase().startsWith(args[1].toLowerCase())) list.add(r.getId());
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            for (CustomWeapon w : plugin.getWeaponManager().getAllWeapons()) {
                if (w.getId().toLowerCase().startsWith(args[1].toLowerCase())) list.add(w.getId());
            }
        }
        return list;
    }
}
