package com.smp.ritual.models;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class CustomWeapon {

    private final String id;
    private final String displayName;
    private final Material baseMaterial;
    private final int customModelData;
    private final int tier;
    private final int maxTier;
    private final double attackDamage;
    private final double attackSpeed;
    private final List<String> loreLines;
    private final String evolutionType;
    private final int evolutionAmount;
    private final String nextWeaponId;

    public CustomWeapon(String id, String displayName, Material baseMaterial, int customModelData,
                        int tier, int maxTier, double attackDamage, double attackSpeed,
                        List<String> loreLines, String evolutionType, int evolutionAmount, String nextWeaponId) {
        this.id = id;
        this.displayName = displayName;
        this.baseMaterial = baseMaterial != null ? baseMaterial : Material.TRIDENT;
        this.customModelData = customModelData;
        this.tier = tier;
        this.maxTier = maxTier;
        this.attackDamage = attackDamage;
        this.attackSpeed = attackSpeed;
        this.loreLines = loreLines != null ? loreLines : new ArrayList<>();
        this.evolutionType = evolutionType != null ? evolutionType : "NONE";
        this.evolutionAmount = evolutionAmount;
        this.nextWeaponId = nextWeaponId;
    }

    public ItemStack createItemStack(JavaPlugin plugin, int currentKills) {
        ItemStack item = new ItemStack(baseMaterial);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        MiniMessage mm = MiniMessage.miniMessage();

        // Name
        meta.displayName(mm.deserialize(displayName));

        // Custom Model Data
        if (customModelData > 0) {
            meta.setCustomModelData(customModelData);
        }

        // Lore
        List<Component> lore = new ArrayList<>();
        for (String line : loreLines) {
            String formatted = line.replace("{kills}", String.valueOf(currentKills));
            lore.add(mm.deserialize(formatted));
        }
        meta.lore(lore);

        // PersistentDataContainer
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        NamespacedKey weaponIdKey = new NamespacedKey(plugin, "weapon_id");
        NamespacedKey tierKey = new NamespacedKey(plugin, "tier");
        NamespacedKey killsKey = new NamespacedKey(plugin, "unique_kills");
        NamespacedKey readyKey = new NamespacedKey(plugin, "ready_to_evolve");

        pdc.set(weaponIdKey, PersistentDataType.STRING, id);
        pdc.set(tierKey, PersistentDataType.INTEGER, tier);
        if (!pdc.has(killsKey, PersistentDataType.STRING)) {
            pdc.set(killsKey, PersistentDataType.STRING, "");
        }
        pdc.set(readyKey, PersistentDataType.BYTE, (byte) (currentKills >= evolutionAmount && canEvolve() ? 1 : 0));

        // Attributes (1.21 Paper AttributeModifier with EquipmentSlotGroup)
        if (attackDamage > 0) {
            NamespacedKey damageKey = new NamespacedKey(plugin, "weapon_damage");
            AttributeModifier damageModifier = new AttributeModifier(
                    damageKey,
                    attackDamage - 1.0, // base hand damage is 1.0
                    AttributeModifier.Operation.ADD_NUMBER,
                    EquipmentSlotGroup.MAINHAND
            );
            meta.removeAttributeModifier(Attribute.GENERIC_ATTACK_DAMAGE);
            meta.addAttributeModifier(Attribute.GENERIC_ATTACK_DAMAGE, damageModifier);
        }

        if (attackSpeed > 0) {
            NamespacedKey speedKey = new NamespacedKey(plugin, "weapon_speed");
            AttributeModifier speedModifier = new AttributeModifier(
                    speedKey,
                    attackSpeed - 4.0, // base attack speed is 4.0
                    AttributeModifier.Operation.ADD_NUMBER,
                    EquipmentSlotGroup.MAINHAND
            );
            meta.removeAttributeModifier(Attribute.GENERIC_ATTACK_SPEED);
            meta.addAttributeModifier(Attribute.GENERIC_ATTACK_SPEED, speedModifier);
        }

        meta.setUnbreakable(true);
        item.setItemMeta(meta);
        return item;
    }

    public boolean canEvolve() {
        return !"NONE".equalsIgnoreCase(evolutionType) && nextWeaponId != null && !nextWeaponId.isEmpty();
    }

    public List<UUID> getKilledPlayerUUIDs(ItemMeta meta, JavaPlugin plugin) {
        List<UUID> list = new ArrayList<>();
        if (meta == null) return list;
        NamespacedKey killsKey = new NamespacedKey(plugin, "unique_kills");
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        String raw = pdc.get(killsKey, PersistentDataType.STRING);
        if (raw == null || raw.isEmpty()) return list;

        for (String part : raw.split(",")) {
            try {
                if (!part.trim().isEmpty()) {
                    list.add(UUID.fromString(part.trim()));
                }
            } catch (IllegalArgumentException ignored) {}
        }
        return list;
    }

    public void updateLoreAndEvolution(ItemStack item, JavaPlugin plugin, List<UUID> kills) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        MiniMessage mm = MiniMessage.miniMessage();
        List<Component> lore = new ArrayList<>();
        int count = kills.size();

        for (String line : loreLines) {
            String formatted = line.replace("{kills}", String.valueOf(count));
            lore.add(mm.deserialize(formatted));
        }

        if (canEvolve() && count >= evolutionAmount) {
            lore.add(mm.deserialize("<green><bold>⚡ READY TO EVOLVE! Hold and Shift! ⚡</bold></green>"));
        }

        meta.lore(lore);

        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        NamespacedKey killsKey = new NamespacedKey(plugin, "unique_kills");
        NamespacedKey readyKey = new NamespacedKey(plugin, "ready_to_evolve");

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < kills.size(); i++) {
            sb.append(kills.get(i).toString());
            if (i < kills.size() - 1) sb.append(",");
        }
        pdc.set(killsKey, PersistentDataType.STRING, sb.toString());
        pdc.set(readyKey, PersistentDataType.BYTE, (byte) (count >= evolutionAmount && canEvolve() ? 1 : 0));

        item.setItemMeta(meta);
    }

    public String getId() { return id; }
    public String getDisplayName() { return displayName; }
    public Material getBaseMaterial() { return baseMaterial; }
    public int getCustomModelData() { return customModelData; }
    public int getTier() { return tier; }
    public int getMaxTier() { return maxTier; }
    public double getAttackDamage() { return attackDamage; }
    public double getAttackSpeed() { return attackSpeed; }
    public String getEvolutionType() { return evolutionType; }
    public int getEvolutionAmount() { return evolutionAmount; }
    public String getNextWeaponId() { return nextWeaponId; }
}
