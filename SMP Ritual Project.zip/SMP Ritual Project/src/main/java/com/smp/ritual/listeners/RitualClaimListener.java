package com.smp.ritual.listeners;

import com.smp.ritual.SMPRitualPlugin;
import com.smp.ritual.models.ActiveRitual;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;

public class RitualClaimListener implements Listener {

    private final SMPRitualPlugin plugin;

    public RitualClaimListener(SMPRitualPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInteractAtEntity(PlayerInteractAtEntityEvent event) {
        handleClaim(event.getPlayer(), event.getRightClicked());
    }

    @EventHandler
    public void onInteractEntity(PlayerInteractEntityEvent event) {
        handleClaim(event.getPlayer(), event.getRightClicked());
    }

    private void handleClaim(Player player, org.bukkit.entity.Entity entity) {
        ActiveRitual ritual = plugin.getRitualManager().getActiveRitual();
        if (ritual == null || !ritual.isCompleted() || ritual.isClaimed()) return;

        if (ritual.getClaimEntityUUID() != null && ritual.getClaimEntityUUID().equals(entity.getUniqueId())) {
            plugin.getRitualManager().claimReward(player, ritual);
        }
    }
}
