package com.smp.ritual.commands;

import com.smp.ritual.SMPRitualPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class RitualsCommand implements CommandExecutor {

    private final SMPRitualPlugin plugin;

    public RitualsCommand(SMPRitualPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used by players.");
            return true;
        }

        plugin.getGuiManager().openRecipeMenu(player);
        return true;
    }
}
