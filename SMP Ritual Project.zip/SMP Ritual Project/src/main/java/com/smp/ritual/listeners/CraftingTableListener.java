package com.smp.ritual.listeners;

import com.smp.ritual.SMPRitualPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEvent;

public class CraftingTableListener implements Listener {

    private final SMPRitualPlugin plugin;

    public CraftingTableListener(SMPRitualPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onOpenCraftingTable(InventoryOpenEvent event) {
        if (!plugin.getConfig().getBoolean("settings.crafting_table_hook", true)) return;
        if (event.getInventory().getType() != InventoryType.WORKBENCH) return;

        if (event.getPlayer() instanceof Player player) {
            Component message = plugin.getMiniMessage().deserialize(
                    "<gold><bold>[✦ SMP Rituals]</bold></gold> <yellow>Click here or type </yellow><aqua>/rituals</aqua><yellow> to view custom ritual recipes!</yellow>"
            ).clickEvent(ClickEvent.runCommand("/rituals"))
             .hoverEvent(HoverEvent.showText(plugin.getMiniMessage().deserialize("<gray>Click to open the Ritual Crafting Catalog</gray>")));

            player.sendMessage(message);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onSneakInteractCraftingTable(PlayerInteractEvent event) {
        if (!plugin.getConfig().getBoolean("settings.crafting_table_hook", true)) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null || event.getClickedBlock().getType() != Material.CRAFTING_TABLE) return;

        Player player = event.getPlayer();
        if (player.isSneaking()) {
            event.setCancelled(true);
            plugin.getGuiManager().openRecipeMenu(player);
        }
    }
}
