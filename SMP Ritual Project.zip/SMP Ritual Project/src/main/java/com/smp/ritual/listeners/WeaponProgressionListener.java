package com.smp.ritual.listeners;

import com.smp.ritual.SMPRitualPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.ItemStack;

public class WeaponProgressionListener implements Listener {

    private final SMPRitualPlugin plugin;

    public WeaponProgressionListener(SMPRitualPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerKill(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();
        if (killer != null && !killer.equals(victim)) {
            plugin.getWeaponManager().handlePlayerKill(killer, victim);
        }
    }

    @EventHandler
    public void onPlayerSneak(PlayerToggleSneakEvent event) {
        // Only trigger on starting to sneak
        if (!event.isSneaking()) return;

        Player player = event.getPlayer();
        ItemStack hand = player.getInventory().getItemInMainHand();

        if (plugin.getWeaponManager().isCustomWeapon(hand)) {
            plugin.getWeaponManager().tryEvolveWeapon(player, hand);
        }
    }
}
