package com.smp.ritual.models;

import org.bukkit.Material;

import java.util.List;

public class RitualRecipe {

    public static class Ingredient {
        private final Material material;
        private final int amount;

        public Ingredient(Material material, int amount) {
            this.material = material;
            this.amount = amount;
        }

        public Material getMaterial() { return material; }
        public int getAmount() { return amount; }
    }

    private final String id;
    private final String displayName;
    private final String dimension;
    private final String tier;
    private final int durationSeconds;
    private final boolean unique;
    private final String resultWeaponId;
    private final int yRevealSeconds;
    private final int xRevealSeconds;
    private final int zRevealSeconds;
    private final List<Ingredient> ingredients;

    public RitualRecipe(String id, String displayName, String dimension, String tier,
                        int durationSeconds, boolean unique, String resultWeaponId,
                        int yRevealSeconds, int xRevealSeconds, int zRevealSeconds,
                        List<Ingredient> ingredients) {
        this.id = id;
        this.displayName = displayName;
        this.dimension = dimension;
        this.tier = tier;
        this.durationSeconds = durationSeconds;
        this.unique = unique;
        this.resultWeaponId = resultWeaponId;
        this.yRevealSeconds = yRevealSeconds;
        this.xRevealSeconds = xRevealSeconds;
        this.zRevealSeconds = zRevealSeconds;
        this.ingredients = ingredients;
    }

    public String getId() { return id; }
    public String getDisplayName() { return displayName; }
    public String getDimension() { return dimension; }
    public String getTier() { return tier; }
    public int getDurationSeconds() { return durationSeconds; }
    public boolean isUnique() { return unique; }
    public String getResultWeaponId() { return resultWeaponId; }
    public int getYRevealSeconds() { return yRevealSeconds; }
    public int getXRevealSeconds() { return xRevealSeconds; }
    public int getZRevealSeconds() { return zRevealSeconds; }
    public List<Ingredient> getIngredients() { return ingredients; }
}
