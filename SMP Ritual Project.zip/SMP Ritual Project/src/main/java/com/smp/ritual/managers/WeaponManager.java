package com.smp.ritual.managers;

import com.smp.ritual.SMPRitualPlugin;
import com.smp.ritual.models.CustomWeapon;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.util.*;

public class WeaponManager {

    private final SMPRitualPlugin plugin;
    private final Map<String, CustomWeapon> weaponMap = new HashMap<>();

    public WeaponManager(SMPRitualPlugin plugin) {
        this.plugin = plugin;
    }

    public void loadWeapons() {
        weaponMap.clear();
        File file = new File(plugin.getDataFolder(), "weapons.yml");
        if (!file.exists()) {
            plugin.saveResource("weapons.yml", false);
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = config.getConfigurationSection("weapons");
        if (section == null) return;

        for (String key : section.getKeys(false)) {
            ConfigurationSection sec = section.getConfigurationSection(key);
            if (sec == null) continue;

            String id = sec.getString("id", key);
            String displayName = sec.getString("display_name", key);
            String matName = sec.getString("base_material", "TRIDENT");
            Material mat = Material.matchMaterial(matName);
            if (mat == null) mat = Material.TRIDENT;

            int cmd = sec.getInt("custom_model_data", 0);
            int tier = sec.getInt("tier", 1);
            int maxTier = sec.getInt("max_tier", 1);
            double dmg = sec.getDouble("attack_damage", 7.0);
            double speed = sec.getDouble("attack_speed", 1.0);
            List<String> lore = sec.getStringList("lore");

            ConfigurationSection evoSec = sec.getConfigurationSection("evolution");
            String evoType = "NONE";
            int evoAmount = 0;
            String nextWeapon = null;
            if (evoSec != null) {
                evoType = evoSec.getString("type", "NONE");
                evoAmount = evoSec.getInt("required_amount", 1);
                nextWeapon = evoSec.getString("next_weapon_id", null);
            }

            CustomWeapon cw = new CustomWeapon(
                    id, displayName, mat, cmd, tier, maxTier, dmg, speed, lore, evoType, evoAmount, nextWeapon
            );
            weaponMap.put(id, cw);
        }

        plugin.getLogger().info("Loaded " + weaponMap.size() + " custom weapons.");
    }

    public CustomWeapon getWeapon(String id) {
        return weaponMap.get(id);
    }

    public Collection<CustomWeapon> getAllWeapons() {
        return weaponMap.values();
    }

    public ItemStack createWeaponItemStack(String id, int currentKills) {
        if ("relic_shulker".equalsIgnoreCase(id)) {
            return createRelicShulkerBox();
        }
        CustomWeapon cw = getWeapon(id);
        if (cw == null) return null;
        return cw.createItemStack(plugin, currentKills);
    }

    public ItemStack createRelicShulkerBox() {
        ItemStack boxItem = new ItemStack(Material.PURPLE_SHULKER_BOX);
        ItemMeta meta = boxItem.getItemMeta();
        if (meta instanceof org.bukkit.inventory.meta.BlockStateMeta bsm) {
            if (bsm.getBlockState() instanceof org.bukkit.block.ShulkerBox box) {
                org.bukkit.inventory.Inventory inv = box.getInventory();
                inv.setItem(4, new ItemStack(Material.ENCHANTED_GOLDEN_APPLE, 2));
                inv.setItem(11, new ItemStack(Material.NETHERITE_INGOT, 2));
                inv.setItem(13, new ItemStack(Material.ECHO_SHARD, 4));
                inv.setItem(15, new ItemStack(Material.DIAMOND, 8));
                inv.setItem(22, new ItemStack(Material.EXPERIENCE_BOTTLE, 32));
                bsm.setBlockState(box);
            }
        }
        if (meta != null) {
            meta.displayName(plugin.getMiniMessage().deserialize("<gradient:#d500f9:#651fff><bold>Ancient Relic Shulker Box</bold></gradient>"));
            List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
            lore.add(plugin.getMiniMessage().deserialize("<dark_gray>Ritual Loot Container</dark_gray>"));
            lore.add(net.kyori.adventure.text.Component.empty());
            lore.add(plugin.getMiniMessage().deserialize("<yellow>Contains ancient treasures extracted from the ritual.</yellow>"));
            lore.add(plugin.getMiniMessage().deserialize("<light_purple>Place down to access sealed contents.</light_purple>"));
            meta.lore(lore);
            boxItem.setItemMeta(meta);
        }
        return boxItem;
    }

    public boolean isCustomWeapon(ItemStack item) {
        if (item == null || item.getType() == Material.AIR || !item.hasItemMeta()) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        NamespacedKey weaponIdKey = new NamespacedKey(plugin, "weapon_id");
        return meta.getPersistentDataContainer().has(weaponIdKey, PersistentDataType.STRING);
    }

    public CustomWeapon getCustomWeapon(ItemStack item) {
        if (!isCustomWeapon(item)) return null;
        NamespacedKey weaponIdKey = new NamespacedKey(plugin, "weapon_id");
        String id = item.getItemMeta().getPersistentDataContainer().get(weaponIdKey, PersistentDataType.STRING);
        return id != null ? getWeapon(id) : null;
    }

    public void handlePlayerKill(Player killer, Player victim) {
        if (killer.equals(victim)) return;
        ItemStack hand = killer.getInventory().getItemInMainHand();
        CustomWeapon cw = getCustomWeapon(hand);
        if (cw == null || !cw.canEvolve()) return;

        ItemMeta meta = hand.getItemMeta();
        List<UUID> kills = cw.getKilledPlayerUUIDs(meta, plugin);

        // Check if victim is unique
        if (!kills.contains(victim.getUniqueId())) {
            kills.add(victim.getUniqueId());
            cw.updateLoreAndEvolution(hand, plugin, kills);

            killer.sendMessage(plugin.getMiniMessage().deserialize(
                    "<gold>⚔ Your <yellow>" + cw.getDisplayName() + "</yellow> tasted new blood! Unique Kills: <white>"
                            + kills.size() + "/" + cw.getEvolutionAmount() + "</white></gold>"
            ));

            if (kills.size() >= cw.getEvolutionAmount()) {
                killer.sendMessage(plugin.getMiniMessage().deserialize(
                        "<green><bold>⚡ EVOLUTION READY! Hold this weapon and press Shift to awaken it!</bold></green>"
                ));
                killer.playSound(killer.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.2f);
                killer.spawnParticle(Particle.ENCHANT, killer.getLocation().add(0, 1, 0), 30, 0.5, 0.5, 0.5, 0.1);
            }
        }
    }

    public boolean tryEvolveWeapon(Player player, ItemStack hand) {
        CustomWeapon cw = getCustomWeapon(hand);
        if (cw == null || !cw.canEvolve()) return false;

        ItemMeta meta = hand.getItemMeta();
        if (meta == null) return false;

        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        NamespacedKey readyKey = new NamespacedKey(plugin, "ready_to_evolve");
        Byte ready = pdc.get(readyKey, PersistentDataType.BYTE);

        if (ready == null || ready == 0) return false;

        String nextId = cw.getNextWeaponId();
        CustomWeapon evolved = getWeapon(nextId);
        if (evolved == null) return false;

        ItemStack evolvedItem = evolved.createItemStack(plugin, 0);
        player.getInventory().setItemInMainHand(evolvedItem);

        // Effects
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
        player.playSound(player.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.7f, 1.4f);
        player.spawnParticle(Particle.TOTEM_OF_UNDYING, player.getLocation().add(0, 1.2, 0), 80, 0.5, 0.8, 0.5, 0.2);
        player.spawnParticle(Particle.FLAME, player.getLocation().add(0, 1.0, 0), 40, 0.4, 0.4, 0.4, 0.05);

        player.sendMessage(plugin.getMiniMessage().deserialize(
                "<gradient:#ff5500:#ffff55><bold>✦ ARTEFACT EVOLVED! ✦</bold></gradient>\n" +
                "<gray>Your weapon has transformed into </gray>" + evolved.getDisplayName() + "<gray>!</gray>"
        ));

        return true;
    }
}
