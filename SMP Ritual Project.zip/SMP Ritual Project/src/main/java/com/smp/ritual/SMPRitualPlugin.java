package com.smp.ritual;

import com.smp.ritual.commands.RitualCommand;
import com.smp.ritual.commands.RitualsCommand;
import com.smp.ritual.listeners.CraftingTableListener;
import com.smp.ritual.listeners.GUIListener;
import com.smp.ritual.listeners.RitualClaimListener;
import com.smp.ritual.listeners.WeaponProgressionListener;
import com.smp.ritual.managers.GUIManager;
import com.smp.ritual.managers.RitualManager;
import com.smp.ritual.managers.WeaponManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public final class SMPRitualPlugin extends JavaPlugin {

    private static SMPRitualPlugin instance;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();

    private WeaponManager weaponManager;
    private RitualManager ritualManager;
    private GUIManager guiManager;

    @Override
    public void onEnable() {
        instance = this;

        // Save default resources if not present
        saveDefaultConfig();
        saveResourceIfNotExists("recipes.yml");
        saveResourceIfNotExists("weapons.yml");

        // Initialize Managers
        this.weaponManager = new WeaponManager(this);
        this.ritualManager = new RitualManager(this);
        this.guiManager = new GUIManager(this);

        // Load configs
        this.weaponManager.loadWeapons();
        this.ritualManager.loadRecipes();

        // Register Listeners
        getServer().getPluginManager().registerEvents(new CraftingTableListener(this), this);
        getServer().getPluginManager().registerEvents(new GUIListener(this), this);
        getServer().getPluginManager().registerEvents(new RitualClaimListener(this), this);
        getServer().getPluginManager().registerEvents(new WeaponProgressionListener(this), this);
        getServer().getPluginManager().registerEvents(new com.smp.ritual.listeners.WeaponAbilityListener(this), this);

        // Register Commands
        if (getCommand("ritual") != null) {
            getCommand("ritual").setExecutor(new RitualCommand(this));
            getCommand("ritual").setTabCompleter(new RitualCommand(this));
        }
        if (getCommand("rituals") != null) {
            getCommand("rituals").setExecutor(new RitualsCommand(this));
        }

        getLogger().info("SMP Ritual & Weapon Plugin enabled successfully!");
    }

    @Override
    public void onDisable() {
        if (this.ritualManager != null) {
            this.ritualManager.onDisable();
        }
        getLogger().info("SMP Ritual & Weapon Plugin disabled.");
    }

    private void saveResourceIfNotExists(String resourcePath) {
        File file = new File(getDataFolder(), resourcePath);
        if (!file.exists()) {
            saveResource(resourcePath, false);
        }
    }

    public static SMPRitualPlugin getInstance() {
        return instance;
    }

    public MiniMessage getMiniMessage() {
        return miniMessage;
    }

    public WeaponManager getWeaponManager() {
        return weaponManager;
    }

    public RitualManager getRitualManager() {
        return ritualManager;
    }

    public GUIManager getGuiManager() {
        return guiManager;
    }
}
