package com.smp.ritual.managers;

import com.smp.ritual.SMPRitualPlugin;
import com.smp.ritual.models.RitualRecipe;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GUIManager {

    private final SMPRitualPlugin plugin;
    public static final String GUI_TITLE = "<gradient:#ffaa00:#ff5500><bold>SMP Ritual Crafting</bold></gradient>";
    public static final String TRACKER_TITLE = "<gradient:#a855f7:#ec4899><bold>Active Ritual Tracker</bold></gradient>";

    public GUIManager(SMPRitualPlugin plugin) {
        this.plugin = plugin;
    }

    public void openRecipeMenu(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, plugin.getMiniMessage().deserialize(GUI_TITLE));

        // Decorative borders
        ItemStack border = createItem(Material.GRAY_STAINED_GLASS_PANE, "<dark_gray> </dark_gray>");
        for (int i = 0; i < 9; i++) inv.setItem(i, border);
        for (int i = 45; i < 54; i++) inv.setItem(i, border);
        inv.setItem(9, border);
        inv.setItem(17, border);
        inv.setItem(18, border);
        inv.setItem(26, border);
        inv.setItem(27, border);
        inv.setItem(35, border);
        inv.setItem(36, border);
        inv.setItem(44, border);

        // Header info item
        ItemStack info = createItem(Material.ENCHANTED_BOOK, "<gold><bold>SMP Ritual System</bold></gold>",
                "<gray>Select a ritual recipe to initiate its crafting.</gray>",
                "<yellow>• Ingredients are consumed automatically on click.</yellow>",
                "<yellow>• Coordinates will be revealed in stages to all players.</yellow>",
                "<red>• Anyone on the SMP can contest and claim the final reward!</red>"
        );
        inv.setItem(4, info);

        // Populate available recipes
        int slot = 19;
        for (RitualRecipe recipe : plugin.getRitualManager().getAllRecipes()) {
            // Remove unique recipes that have already been claimed (as per specs)
            if (!plugin.getRitualManager().isRecipeAvailable(recipe)) {
                continue;
            }

            ItemStack icon = createRecipeIcon(player, recipe);
            inv.setItem(slot, icon);
            slot++;
            if (slot == 26) slot = 28;
            if (slot == 35) slot = 37;
            if (slot >= 44) break;
        }

        player.openInventory(inv);
        player.playSound(player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 0.8f, 1.0f);
    }

    public ItemStack createRecipeIcon(Player player, RitualRecipe recipe) {
        Material displayMat = Material.BEACON;
        if ("OVERWORLD".equalsIgnoreCase(recipe.getDimension())) {
            displayMat = Material.GRASS_BLOCK;
        } else if ("THE_NETHER".equalsIgnoreCase(recipe.getDimension())) {
            displayMat = Material.NETHERRACK;
        } else if ("THE_END".equalsIgnoreCase(recipe.getDimension())) {
            displayMat = Material.END_STONE;
        }

        boolean canCraft = hasIngredients(player, recipe);

        MiniMessage mm = plugin.getMiniMessage();
        List<Component> lore = new ArrayList<>();
        lore.add(mm.deserialize("<dark_gray>Ritual Recipe</dark_gray>"));
        lore.add(Component.empty());
        lore.add(mm.deserialize("<gray>Dimension: </gray><aqua>" + recipe.getDimension() + "</aqua>"));
        lore.add(mm.deserialize("<gray>Tier: </gray><yellow>" + recipe.getTier() + "</yellow>"));
        lore.add(mm.deserialize("<gray>Duration: </gray><gold>" + (recipe.getDurationSeconds() / 60) + " minutes</gold>"));
        lore.add(mm.deserialize("<gray>Server Uniqueness: </gray>" + (recipe.isUnique() ? "<gold>One-Time Craft</gold>" : "<green>Repeatable</green>")));
        lore.add(Component.empty());
        lore.add(mm.deserialize("<yellow><bold>Coordinate Reveal Schedule:</bold></yellow>"));
        lore.add(mm.deserialize("<gray>• Y Level: <white>At Start (00:00)</white></gray>"));
        lore.add(mm.deserialize("<gray>• X Coordinate: <white>At " + formatTime(recipe.getXRevealSeconds()) + "</white></gray>"));
        lore.add(mm.deserialize("<gray>• Z Coordinate: <white>At " + formatTime(recipe.getZRevealSeconds()) + "</white></gray>"));
        lore.add(Component.empty());
        lore.add(mm.deserialize("<gold><bold>Required Ingredients:</bold></gold>"));

        for (RitualRecipe.Ingredient ing : recipe.getIngredients()) {
            int current = countMaterial(player, ing.getMaterial());
            boolean has = current >= ing.getAmount();
            String check = has ? "<green>✔</green>" : "<red>✘</red>";
            String color = has ? "<green>" : "<red>";
            lore.add(mm.deserialize("  " + check + " " + color + current + "/" + ing.getAmount() + "x " + formatMaterialName(ing.getMaterial()) + "</color>"));
        }

        lore.add(Component.empty());
        if (canCraft) {
            lore.add(mm.deserialize("<green><bold>▶ CLICK TO CONSUME & START RITUAL</bold></green>"));
        } else {
            lore.add(mm.deserialize("<red><bold>✖ MISSING REQUIRED INGREDIENTS</bold></red>"));
        }

        ItemStack item = new ItemStack(displayMat);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(mm.deserialize(recipe.getDisplayName()));
            meta.lore(lore);

            NamespacedKey key = new NamespacedKey(plugin, "recipe_id");
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, recipe.getId());
            item.setItemMeta(meta);
        }
        return item;
    }

    public boolean hasIngredients(Player player, RitualRecipe recipe) {
        for (RitualRecipe.Ingredient ing : recipe.getIngredients()) {
            if (countMaterial(player, ing.getMaterial()) < ing.getAmount()) {
                return false;
            }
        }
        return true;
    }

    public boolean consumeIngredients(Player player, RitualRecipe recipe) {
        if (!hasIngredients(player, recipe)) return false;

        for (RitualRecipe.Ingredient ing : recipe.getIngredients()) {
            removeMaterial(player, ing.getMaterial(), ing.getAmount());
        }
        player.updateInventory();
        return true;
    }

    private int countMaterial(Player player, Material mat) {
        int count = 0;
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.getType() == mat) {
                count += item.getAmount();
            }
        }
        return count;
    }

    private void removeMaterial(Player player, Material mat, int amount) {
        ItemStack[] contents = player.getInventory().getContents();
        int remaining = amount;
        for (int i = 0; i < contents.length; i++) {
            ItemStack item = contents[i];
            if (item != null && item.getType() == mat) {
                if (item.getAmount() <= remaining) {
                    remaining -= item.getAmount();
                    contents[i] = null;
                } else {
                    item.setAmount(item.getAmount() - remaining);
                    remaining = 0;
                }
                if (remaining <= 0) break;
            }
        }
        player.getInventory().setContents(contents);
    }

    private String formatMaterialName(Material mat) {
        String[] words = mat.name().toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (String w : words) {
            if (!w.isEmpty()) {
                sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1)).append(" ");
            }
        }
        return sb.toString().trim();
    }

    private String formatTime(int seconds) {
        int m = seconds / 60;
        int s = seconds % 60;
        return String.format("%02d:%02d", m, s);
    }

    public void openTrackerMenu(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, plugin.getMiniMessage().deserialize(TRACKER_TITLE));

        ItemStack border = createItem(Material.PURPLE_STAINED_GLASS_PANE, "<dark_gray> </dark_gray>");
        for (int i = 0; i < 27; i++) inv.setItem(i, border);

        com.smp.ritual.models.ActiveRitual active = plugin.getRitualManager().getActiveRitual();
        if (active == null) {
            ItemStack noRitual = createItem(Material.BARRIER, "<red><bold>No Active Rituals</bold></red>",
                    "<gray>There are currently no rituals in progress on the SMP.</gray>",
                    "<yellow>Use </yellow><gold>/rituals</gold><yellow> to view recipes and start one!</yellow>"
            );
            inv.setItem(13, noRitual);
        } else {
            Material iconMat = active.isCompleted() ? Material.BEACON : Material.CLOCK;
            String status = active.isCompleted() ? "<green><bold>COMPLETED (CLAIMABLE)</bold></green>" : "<gold><bold>IN PROGRESS</bold></gold>";

            String distStr = "<gray>Different Dimension</gray>";
            if (player.getWorld().equals(active.getLocation().getWorld())) {
                int dist = (int) player.getLocation().distance(active.getLocation());
                distStr = "<yellow>Distance: </yellow><white>~" + dist + " blocks</white>";
            }

            ItemStack activeItem = createItem(iconMat, active.getRecipe().getDisplayName(),
                    "<dark_gray>Active Ritual</dark_gray>",
                    "",
                    "<gray>Status: </gray>" + status,
                    "<gray>Dimension: </gray><aqua>" + active.getRecipe().getDimension() + "</aqua>",
                    "<gray>Time Left: </gray><gold>" + active.getRemainingTimeFormatted() + "</gold>",
                    "",
                    "<yellow><bold>Coordinates:</bold></yellow>",
                    "  " + active.getFormattedCoordinates(),
                    distStr,
                    "",
                    active.isCompleted() ? "<green><bold>▶ RUSH TO LOCATION TO CLAIM!</bold></green>" : "<red><bold>⚔ PREPARE TO CONTEST!</bold></red>"
            );
            inv.setItem(13, activeItem);
        }

        player.openInventory(inv);
        player.playSound(player.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 0.7f, 1.2f);
    }

    private ItemStack createItem(Material mat, String name, String... loreLines) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(plugin.getMiniMessage().deserialize(name));
            if (loreLines.length > 0) {
                List<Component> lore = new ArrayList<>();
                for (String l : loreLines) {
                    lore.add(plugin.getMiniMessage().deserialize(l));
                }
                meta.lore(lore);
            }
            item.setItemMeta(meta);
        }
        return item;
    }
}
