package com.smp.ritual.managers;

import com.smp.ritual.SMPRitualPlugin;
import com.smp.ritual.models.ActiveRitual;
import com.smp.ritual.models.RitualRecipe;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class RitualManager {

    private final SMPRitualPlugin plugin;
    private final Map<String, RitualRecipe> recipeMap = new HashMap<>();
    private final Set<String> claimedUniqueRecipes = new HashSet<>();

    private ActiveRitual activeRitual = null;
    private BukkitTask tickTask = null;
    private BukkitTask particleTask = null;

    public RitualManager(SMPRitualPlugin plugin) {
        this.plugin = plugin;
        loadClaimedRecipes();
    }

    public void loadRecipes() {
        recipeMap.clear();
        File file = new File(plugin.getDataFolder(), "recipes.yml");
        if (!file.exists()) {
            plugin.saveResource("recipes.yml", false);
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = config.getConfigurationSection("recipes");
        if (section == null) return;

        for (String key : section.getKeys(false)) {
            ConfigurationSection sec = section.getConfigurationSection(key);
            if (sec == null) continue;

            String id = sec.getString("id", key);
            String displayName = sec.getString("display_name", key);
            String dim = sec.getString("dimension", "OVERWORLD");
            String tier = sec.getString("tier", "STARTER");
            int duration = sec.getInt("duration_seconds", 900);
            boolean unique = sec.getBoolean("unique", false);
            String resultWeapon = sec.getString("result_weapon_id", key);

            int ySec = sec.getInt("reveals.y_seconds", 0);
            int xSec = sec.getInt("reveals.x_seconds", 180);
            int zSec = sec.getInt("reveals.z_seconds", 360);

            List<RitualRecipe.Ingredient> ingredients = new ArrayList<>();
            List<Map<?, ?>> ingList = sec.getMapList("ingredients");
            for (Map<?, ?> entry : ingList) {
                String matStr = (String) entry.get("material");
                int amount = entry.containsKey("amount") ? ((Number) entry.get("amount")).intValue() : 1;
                Material mat = Material.matchMaterial(matStr != null ? matStr : "");
                if (mat != null) {
                    ingredients.add(new RitualRecipe.Ingredient(mat, amount));
                }
            }

            RitualRecipe recipe = new RitualRecipe(
                    id, displayName, dim, tier, duration, unique, resultWeapon, ySec, xSec, zSec, ingredients
            );
            recipeMap.put(id, recipe);
        }

        plugin.getLogger().info("Loaded " + recipeMap.size() + " ritual recipes.");
    }

    public void loadClaimedRecipes() {
        claimedUniqueRecipes.clear();
        File file = new File(plugin.getDataFolder(), "data.yml");
        if (!file.exists()) return;
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        List<String> list = config.getStringList("claimed_unique_recipes");
        claimedUniqueRecipes.addAll(list);
    }

    public void saveClaimedRecipes() {
        File file = new File(plugin.getDataFolder(), "data.yml");
        YamlConfiguration config = new YamlConfiguration();
        config.set("claimed_unique_recipes", new ArrayList<>(claimedUniqueRecipes));
        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to save data.yml: " + e.getMessage());
        }
    }

    public boolean isRecipeAvailable(RitualRecipe recipe) {
        if (recipe.isUnique() && claimedUniqueRecipes.contains(recipe.getId())) {
            return false;
        }
        return true;
    }

    public boolean startRitual(Player starter, RitualRecipe recipe, Location loc) {
        if (activeRitual != null) {
            starter.sendMessage(plugin.getMiniMessage().deserialize("<red>Another ritual is currently active on the SMP!</red>"));
            return false;
        }

        if (!isRecipeAvailable(recipe)) {
            starter.sendMessage(plugin.getMiniMessage().deserialize("<red>This unique recipe has already been completed and claimed!</red>"));
            return false;
        }

        activeRitual = new ActiveRitual(recipe, loc, starter.getUniqueId(), starter.getName());

        // Setup BossBar
        BossBar.Color color = BossBar.Color.PURPLE;
        try {
            String colStr = plugin.getConfig().getString("settings.bossbar_color", "PURPLE");
            color = BossBar.Color.valueOf(colStr.toUpperCase());
        } catch (IllegalArgumentException ignored) {}

        BossBar bb = BossBar.bossBar(
                Component.empty(),
                1.0f,
                color,
                BossBar.Overlay.PROGRESS
        );
        activeRitual.setBossBar(bb);

        for (Player p : Bukkit.getOnlinePlayers()) {
            p.showBossBar(bb);
        }

        // Global broadcast
        if (plugin.getConfig().getBoolean("settings.broadcast_ritual_start", true)) {
            Bukkit.broadcast(plugin.getMiniMessage().deserialize(
                    "\n<gold><bold>⚡ RITUAL INITIATED! ⚡</bold></gold>\n" +
                    "<gray>A ritual for </gray>" + recipe.getDisplayName() + " <gray>has begun!</gray>\n" +
                    "<yellow>Initial Coordinates: </yellow>" + activeRitual.getFormattedCoordinates() + "\n" +
                    "<dark_gray>Duration: " + activeRitual.getRemainingTimeFormatted() + " | Contestable by anyone!</dark_gray>\n"
            ));
        }

        startTicker();
        return true;
    }

    private void startTicker() {
        if (tickTask != null) tickTask.cancel();

        tickTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (activeRitual == null) {
                stopTicker();
                return;
            }

            int prevSec = activeRitual.getElapsedSeconds();
            activeRitual.tick();
            int currSec = activeRitual.getElapsedSeconds();

            // Check reveals
            RitualRecipe recipe = activeRitual.getRecipe();
            if (currSec == recipe.getXRevealSeconds() && currSec > prevSec) {
                broadcastReveal("X Coordinate Revealed: <white>" + activeRitual.getLocation().getBlockX() + "</white>");
            }
            if (currSec == recipe.getZRevealSeconds() && currSec > prevSec) {
                broadcastReveal("Z Coordinate Revealed: <white>" + activeRitual.getLocation().getBlockZ() + "</white>");
            }

            // Update BossBar
            BossBar bb = activeRitual.getBossBar();
            if (bb != null) {
                float progress = Math.max(0.0f, 1.0f - ((float) currSec / activeRitual.getTotalSeconds()));
                bb.progress(progress);

                Component title = plugin.getMiniMessage().deserialize(
                        "<gold><bold>Ritual: </bold></gold>" + recipe.getDisplayName() +
                        " <dark_gray>|</dark_gray> " + activeRitual.getFormattedCoordinates() +
                        " <dark_gray>|</dark_gray> <aqua><bold>" + activeRitual.getRemainingTimeFormatted() + "</bold></aqua>"
                );
                bb.name(title);
            }

            // Check completion
            if (activeRitual.isCompleted() && activeRitual.getClaimEntityUUID() == null) {
                onRitualComplete();
            }
        }, 20L, 20L);
    }

    private void broadcastReveal(String message) {
        if (plugin.getConfig().getBoolean("settings.broadcast_coordinate_reveal", true)) {
            Bukkit.broadcast(plugin.getMiniMessage().deserialize(
                    "<yellow><bold>⚠ RITUAL UPDATE ⚠</bold></yellow> " + message +
                    " | <gray>Current: </gray>" + activeRitual.getFormattedCoordinates()
            ));
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 1.2f);
            }
        }
    }

    private void onRitualComplete() {
        Location loc = activeRitual.getLocation().clone().add(0.5, 1.0, 0.5);
        World world = loc.getWorld();
        if (world == null) return;

        // Spawn interactive claim ArmorStand
        ArmorStand stand = world.spawn(loc, ArmorStand.class, as -> {
            as.setVisible(false);
            as.setGravity(false);
            as.setCustomNameVisible(true);
            as.customName(plugin.getMiniMessage().deserialize(
                    "<gold><bold>✦ RIGHT-CLICK TO CLAIM " + activeRitual.getRecipe().getDisplayName() + " ✦</bold></gold>"
            ));
            as.setInvulnerable(true);
        });

        activeRitual.setClaimEntityUUID(stand.getUniqueId());

        // Spawn particle beacon
        startParticleBeacon(loc);

        // Global announcement
        if (plugin.getConfig().getBoolean("settings.broadcast_ritual_complete", true)) {
            Bukkit.broadcast(plugin.getMiniMessage().deserialize(
                    "\n<green><bold>★ RITUAL COMPLETED! ★</bold></green>\n" +
                    "<gray>The ritual at </gray>" + activeRitual.getFormattedCoordinates() + " <gray>is finished!</gray>\n" +
                    "<red><bold>The reward is now UNPROTECTED and claimable by ANY player!</bold></red>\n"
            ));
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
            }
        }
    }

    private void startParticleBeacon(Location loc) {
        if (particleTask != null) particleTask.cancel();

        particleTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (activeRitual == null || activeRitual.isClaimed()) {
                if (particleTask != null) particleTask.cancel();
                return;
            }
            World w = loc.getWorld();
            if (w == null) return;

            w.spawnParticle(Particle.PORTAL, loc, 25, 0.5, 0.5, 0.5, 0.1);
            w.spawnParticle(Particle.ENCHANT, loc.clone().add(0, 0.5, 0), 20, 0.5, 0.5, 0.5, 0.5);
            w.spawnParticle(Particle.END_ROD, loc.clone().add(0, 1.5, 0), 5, 0.2, 0.5, 0.2, 0.02);
        }, 10L, 10L);
    }

    public boolean claimReward(Player claimer, ActiveRitual ritual) {
        if (ritual == null || !ritual.isCompleted() || ritual.isClaimed()) return false;

        ritual.setClaimed(true);

        // Give weapon to claimer
        String weaponId = ritual.getRecipe().getResultWeaponId();
        ItemStack rewardItem = plugin.getWeaponManager().createWeaponItemStack(weaponId, 0);

        if (rewardItem != null) {
            HashMap<Integer, ItemStack> leftover = claimer.getInventory().addItem(rewardItem);
            if (!leftover.isEmpty()) {
                for (ItemStack drop : leftover.values()) {
                    claimer.getWorld().dropItemNaturally(claimer.getLocation(), drop);
                }
            }
        }

        // Clean up entity
        if (ritual.getClaimEntityUUID() != null) {
            Entity ent = Bukkit.getEntity(ritual.getClaimEntityUUID());
            if (ent != null) ent.remove();
        }

        // Mark unique recipe if applicable
        if (ritual.getRecipe().isUnique()) {
            claimedUniqueRecipes.add(ritual.getRecipe().getId());
            saveClaimedRecipes();
        }

        // Remove BossBar
        if (ritual.getBossBar() != null) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.hideBossBar(ritual.getBossBar());
            }
        }

        // Announce without revealing location or claimant (as specified in PDF Section 4!)
        if (plugin.getConfig().getBoolean("settings.broadcast_artefact_claim", true)) {
            Bukkit.broadcast(plugin.getMiniMessage().deserialize(
                    "\n<dark_purple><bold>✦ ARTEFACT CLAIMED ✦</bold></dark_purple>\n" +
                    "<gray>An ancient ritual artefact (" + ritual.getRecipe().getDisplayName() + "<gray>) was claimed!</gray>\n" +
                    "<dark_gray>The claimant vanished into the shadows...</dark_gray>\n"
            ));
        }

        claimer.sendMessage(plugin.getMiniMessage().deserialize(
                "<green><bold>You have successfully claimed the " + ritual.getRecipe().getDisplayName() + "<green>! RUN!</bold></green>"
        ));
        claimer.playSound(claimer.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.8f, 1.5f);

        activeRitual = null;
        stopTicker();
        return true;
    }

    public void cancelRitual() {
        if (activeRitual == null) return;

        if (activeRitual.getBossBar() != null) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.hideBossBar(activeRitual.getBossBar());
            }
        }

        if (activeRitual.getClaimEntityUUID() != null) {
            Entity ent = Bukkit.getEntity(activeRitual.getClaimEntityUUID());
            if (ent != null) ent.remove();
        }

        activeRitual = null;
        stopTicker();
    }

    private void stopTicker() {
        if (tickTask != null) {
            tickTask.cancel();
            tickTask = null;
        }
        if (particleTask != null) {
            particleTask.cancel();
            particleTask = null;
        }
    }

    public void onDisable() {
        cancelRitual();
    }

    public ActiveRitual getActiveRitual() { return activeRitual; }
    public RitualRecipe getRecipe(String id) { return recipeMap.get(id); }
    public Collection<RitualRecipe> getAllRecipes() { return recipeMap.values(); }
    public Set<String> getClaimedUniqueRecipes() { return claimedUniqueRecipes; }
}
