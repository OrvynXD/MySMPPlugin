rootProject.name = "SMPRitualPlugin"
